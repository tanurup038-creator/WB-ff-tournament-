from flask import Flask, render_template, request, jsonify, send_file, url_for
import qrcode
import io
import uuid
from datetime import datetime

app = Flask(__name__)

ORDERS = {}
MERCHANT_UPI_ID = "your-upi@upi"

def make_upi_deeplink(upi_id, amount, note, payee_name="Merchant"):
    return f"upi://pay?pa={upi_id}&pn={payee_name}&am={amount:.2f}&tn={note}&cu=INR"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/create_order", methods=["POST"])
def create_order():
    data = request.get_json() or {}
    amount = float(data.get("amount", 10.00))
    receipt = str(uuid.uuid4())
    order_id = "ORD-" + receipt[:8]
    now = datetime.utcnow().isoformat()

    ORDERS[order_id] = {
        "order_id": order_id,
        "amount": amount,
        "status": "created",
        "created_at": now
    }

    upi_link = make_upi_deeplink(MERCHANT_UPI_ID, amount, note=order_id)

    qr = qrcode.QRCode(box_size=6, border=2)
    qr.add_data(upi_link)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    img_byte_arr = io.BytesIO()
    img.save(img_byte_arr, format='PNG')
    img_byte_arr.seek(0)

    ORDERS[order_id]['qr_bytes'] = img_byte_arr.getvalue()

    response = {
        "order_id": order_id,
        "amount": amount,
        "upi_link": upi_link,
        "qr_url": url_for("get_qr", order_id=order_id)
    }
    return jsonify(response), 201

@app.route("/qr/<order_id>")
def get_qr(order_id):
    order = ORDERS.get(order_id)
    if not order or 'qr_bytes' not in order:
        return "Not found", 404
    return send_file(io.BytesIO(order['qr_bytes']), mimetype='image/png')

@app.route("/check_status/<order_id>")
def check_status(order_id):
    order = ORDERS.get(order_id)
    if not order:
        return jsonify({"error":"order_not_found"}), 404
    return jsonify({
        "order_id": order_id,
        "status": order['status'],
        "amount": order['amount']
    })

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.get_json() or {}
    order_id = data.get("order_id")
    status = data.get("status")

    if not order_id or order_id not in ORDERS:
        return jsonify({"error":"unknown_order"}), 400

    if status == "success":
        ORDERS[order_id]['status'] = "paid"
        ORDERS[order_id]['paid_at'] = datetime.utcnow().isoformat()
        ORDERS[order_id]['txn_payload'] = data
    else:
        ORDERS[order_id]['status'] = status or "failed"

    return jsonify({"ok": True})

@app.route("/mark_paid/<order_id>", methods=["POST"])
def mark_paid(order_id):
    if order_id not in ORDERS:
        return jsonify({"error":"order_not_found"}), 404
    ORDERS[order_id]['status'] = 'paid'
    ORDERS[order_id]['paid_at'] = datetime.utcnow().isoformat()
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
